from django.test import TestCase
from datetime import datetime, timedelta
# Create your tests here.
# from django.utils import timezone

# print(timezone.now())
# lambda: print(datetime.now() + timedelta(days=3))
